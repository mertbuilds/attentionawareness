(function(){function e(e,t){let n=e.trim().toLowerCase().replace(/^\*\./u,``).replace(/\.$/u,``),r=t.trim().toLowerCase().replace(/\.$/u,``);return n===``?!1:r===n||r.endsWith(`.${n}`)}function t({hostname:t,rules:n,settings:r,site:i}){if(!r.enabled)return``;let a=[];i!==null&&r.sites[i]&&a.push(n[i]);for(let n of r.custom)n.enabled&&e(n.domain,t)&&a.push(n.css);return a.join(`
`)}var n={instagram:`/*
 * Instagram: instagram.com and its subdomains.
 *
 * Hides: the Reels entry in the nav, the Reels page, the Explore page's grid
 * and its tabs, the "Suggested for you" blocks in the sidebar and in the feed,
 * and the "For you" tab on the home feed. The feed, stories, messages, search
 * and the profile stay.
 *
 * The nav's \`a[href='/explore/']\` stays: on the desktop layout that link is
 * the Search entry, so hiding it takes search with it. Explore is cut one
 * level inside the page instead, where \`main > div\` holds the search box, the
 * tabs and the grid, and only the child with the input survives.
 *
 * Instagram generates its class names, so the hooks here are hrefs: the nav
 * links, and the "See all" link every suggestion block carries. The page level
 * rules read \`html[data-aa-path]\`, which the content script keeps in step with
 * \`location.pathname\`, because Instagram never reloads.
 *
 * Verified 2026-09-11, except the home feed "For you" tab, which Instagram
 * shows to some accounts only; its rule is inert where the tab is absent.
 */

a[href='/reels/'],
li:has(> a[href='/reels/']),
li:has(> div > a[href='/reels/']) {
  display: none !important;
}

html[data-aa-path^='/reels'] main {
  display: none !important;
}

html[data-aa-path^='/explore'] main > div > div:not(:has(input)) {
  display: none !important;
}

div:has(> div > a[href='/explore/people/']) {
  display: none !important;
}

html[data-aa-path='/'] main [role='tablist'] > div:first-child {
  display: none !important;
}
`,tiktok:`/*
 * TikTok: tiktok.com and its subdomains.
 *
 * Hides: all of it. TikTok is a feed with a site drawn around it, so there is
 * no part worth keeping and no selector worth maintaining: every direct child
 * of the body goes, and the note the content script leaves takes the page.
 *
 * Suisse Intl is licensed and never leaves the extension's own pages, so the
 * note is set in the system font of the page it replaces.
 *
 * Verified 2026-09-11.
 */

html,
body {
  background: #000000 !important;
}

body > *:not(#aa-note) {
  display: none !important;
}

#aa-note {
  align-items: center !important;
  background: #000000 !important;
  color: #ffffff !important;
  display: flex !important;
  flex-direction: column !important;
  font-family: 'Suisse Intl', system-ui, sans-serif !important;
  gap: 8px !important;
  inset: 0 !important;
  justify-content: center !important;
  position: fixed !important;
  z-index: 2147483647 !important;
}

#aa-note p {
  font-size: 20px !important;
  letter-spacing: -0.02em !important;
  line-height: 1.2 !important;
  margin: 0 !important;
}

#aa-note p:last-child {
  color: #8a8a8a !important;
  font-size: 15px !important;
}
`,x:`/*
 * X: x.com, twitter.com.
 *
 * Hides: the "For you" tab on the home timeline, and the trends and the news
 * block in the right sidebar. Explore stays, because search lives behind it;
 * the Following feed, notifications, messages and the profile stay untouched.
 *
 * The hooks are \`data-testid\` attributes, the only names X does not hash.
 * \`ScrollSnap-List\` is not the timeline's own: the composer toolbar, the photo
 * carousel inside every tweet and every other tab row (profile, explore,
 * notifications) are the same list, and their first child is the image upload
 * button, the first photo and the first tab. So the rule is keyed on the home
 * path and excludes the toolbar and articles, which leaves the one element it
 * was written for. The "For you" tab is taken out of flow instead of being set
 * to \`display: none\`: it sits in a scroll-snap list that measures its own
 * children, and removing one leaves the underline under nothing.
 *
 * The news box has no section of its own any more: it is reached as the
 * child of the \`Trending\` wrapper that holds a \`news_sidebar\`. That wrapper
 * holds the whole sidebar, so it is never the target itself.
 *
 * Verified 2026-09-17.
 */

html[data-aa-path='/home']
  nav:not([data-testid='toolBar'] nav):not(article nav)
  [data-testid='ScrollSnap-List']
  > div:first-child {
  position: absolute !important;
  visibility: hidden !important;
}

[data-testid='sidebarColumn'] [data-testid='trend'],
[data-testid='sidebarColumn'] [data-testid='news_sidebar'],
[data-testid='sidebarColumn'] section:has([data-testid='trend']),
[data-testid='sidebarColumn'] section:has([data-testid='news_sidebar']),
[data-testid='sidebarColumn']
  [aria-label='Trending']
  > div
  > div:has([data-testid='news_sidebar']) {
  display: none !important;
}
`,youtube:`/*
 * YouTube: youtube.com and its subdomains.
 *
 * Hides: every Shorts surface, which is the shelves on home, subscriptions,
 * search and watch, single Shorts sitting among ordinary results, the Shorts
 * entry in both guides, the Shorts tab on a channel, and the /shorts/ player
 * itself; plus the Playables shelf. The home feed, subscriptions, search and
 * the watch page stay.
 *
 * The hooks are YouTube's own custom element names and the \`is-shorts\`
 * attribute it puts on its own shelves. Both outlive its class names. Search
 * builds its shelf out of a different set of elements than the feed does
 * (\`grid-shelf-view-model\` or \`ytd-shelf-renderer\` around
 * \`ytm-shorts-lockup-view-model\`, with a \`-v2\` lockup in flight), so both
 * shapes are named. A single Short is reached by its /shorts/ link, whatever
 * tile carries it. The Playables shelf carries no attribute of its own, so it
 * is reached by the /playables link inside it. \`:has()\` reaches the section
 * around a shelf so a removed shelf leaves no empty row. Never hide
 * ytd-item-section-renderer on search: it wraps the results too, and an
 * empty viewport makes YouTube keep loading pages. The /shorts/ rules read
 * \`html[data-aa-path]\`, which the content script keeps in step with
 * \`location.pathname\`, because YouTube never reloads.
 *
 * The "Shorts" filter chip on search stays. It carries no attribute and no
 * link that names it, and CSS cannot match an element by its text.
 *
 * Verified 2026-09-12: home, subscriptions, search, watch, channel. The
 * Playables shelf is the exception, which YouTube shows by region; its rule
 * is inert where the shelf is absent.
 */

ytd-reel-shelf-renderer,
ytd-rich-shelf-renderer[is-shorts],
ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts]),
ytd-rich-section-renderer:has(ytm-shorts-lockup-view-model) {
  display: none !important;
}

grid-shelf-view-model:has(ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2),
ytd-shelf-renderer:has(ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2),
ytd-rich-section-renderer:has(ytm-shorts-lockup-view-model-v2),
ytd-video-renderer:has(a[href^='/shorts/']),
ytd-grid-video-renderer:has(a[href^='/shorts/']),
ytd-compact-video-renderer:has(a[href^='/shorts/']),
ytd-rich-item-renderer:has(a[href^='/shorts/']),
yt-lockup-view-model:has(a[href^='/shorts/']),
ytd-guide-entry-renderer:has(a[href^='/shorts']),
ytd-mini-guide-entry-renderer:has(a[href^='/shorts']),
ytd-reel-item-renderer,
ytd-reel-video-renderer {
  display: none !important;
}

ytd-guide-entry-renderer:has(a[title='Shorts']),
ytd-mini-guide-entry-renderer:has(a[title='Shorts']),
yt-tab-shape[tab-title='Shorts'] {
  display: none !important;
}

ytd-rich-section-renderer:has(a[href^='/playables']),
ytd-rich-shelf-renderer:has(a[href^='/playables']) {
  display: none !important;
}

html[data-aa-path^='/shorts'] ytd-shorts {
  display: none !important;
}

/*
 * The note the content script leaves where the player was. It is in the page
 * on every YouTube path, and only the Shorts path shows it.
 */
#aa-note {
  display: none !important;
}

html[data-aa-path^='/shorts'] #aa-note {
  align-items: center !important;
  background: #000000 !important;
  color: #ffffff !important;
  display: flex !important;
  flex-direction: column !important;
  font-family: 'Suisse Intl', system-ui, sans-serif !important;
  gap: 8px !important;
  inset: 56px 0 0 0 !important;
  justify-content: center !important;
  position: fixed !important;
  z-index: 2000 !important;
}

html[data-aa-path^='/shorts'] #aa-note p {
  font-size: 20px !important;
  letter-spacing: -0.02em !important;
  line-height: 1.2 !important;
  margin: 0 !important;
}

html[data-aa-path^='/shorts'] #aa-note p:last-child {
  color: #8a8a8a !important;
  font-size: 15px !important;
}
`},r=[[`instagram.com`,`instagram`],[`tiktok.com`,`tiktok`],[`twitter.com`,`x`],[`x.com`,`x`],[`youtube.com`,`youtube`]];function i(t){for(let[n,i]of r)if(e(n,t))return i;return null}var a={custom:[],enabled:!0,sites:{instagram:!0,tiktok:!0,x:!0,youtube:!0}};function o(e){let t={...a.sites},n=e?.sites;if(l(n))for(let e of Object.keys(t)){let r=n[e];typeof r==`boolean`&&(t[e]=r)}let r=e?.enabled;return{custom:u(e?.custom),enabled:typeof r==`boolean`?r:a.enabled,sites:t}}async function s(){return o(await chrome.storage.sync.get(null))}function c(e){let t=(t,n)=>{n===`sync`&&s().then(e)};return chrome.storage.onChanged.addListener(t),()=>{chrome.storage.onChanged.removeListener(t)}}function l(e){return typeof e==`object`&&!!e}function u(e){return Array.isArray(e)?e.filter(d):[]}function d(e){return l(e)&&typeof e.css==`string`&&typeof e.domain==`string`&&typeof e.enabled==`boolean`&&typeof e.id==`string`}var f=`aa-rules`,p=`aa-note`,m=`data-aa-path`,h=500,g=`TikTok is off.`,_=`Shorts is off.`,v=`attention awareness`,y=i(location.hostname),b=document.createElement(`style`);b.id=f;var x=!1;C(a),y!==null&&(w(),document.addEventListener(`DOMContentLoaded`,E),window.addEventListener(`popstate`,w),setInterval(w,h)),S();async function S(){C(await s()),c(C)}function C(e){let r=t({hostname:location.hostname,rules:n,settings:e,site:y});x=r!==``,x?(b.textContent=r,b.parentNode===null&&document.documentElement.append(b)):(b.remove(),b.textContent=``),E()}function w(){document.documentElement.setAttribute(m,location.pathname),E()}function T(){return x?y===`tiktok`?g:y===`youtube`&&location.pathname.startsWith(`/shorts`)?_:null:null}function E(){let e=T(),t=document.getElementById(p);if(e===null){t?.remove();return}if(document.body===null)return;let n=t??document.createElement(`div`);n.id=p,n.firstElementChild?.textContent!==e&&n.replaceChildren(D(e),D(v)),n.parentElement!==document.body&&document.body.append(n)}function D(e){let t=document.createElement(`p`);return t.textContent=e,t}})();